const E=6,s=3,S=1e3,_={STREAMS:"detected_streams"},t="src/offscreen/index.html";export{E as M,t as O,_ as S,s as a,S as b};
